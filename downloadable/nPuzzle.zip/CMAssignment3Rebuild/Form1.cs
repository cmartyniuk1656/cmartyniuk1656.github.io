﻿//Coded By Chris Martyniuk
//n- puzzle assignment 3
//Oct 31, 2015

using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Text;
using System.Reflection;

namespace CMAssignment3Rebuild
{
    public partial class Form1 : Form
    {
        //Global variable declarations. Mostly lazy public globals for the 
        //attempted ai solver that is worth 0 marks.
        int rows;
        int columns;

        int simulationSpeed = 1;

        string name = "Player";


        int AICounter = 0;
        int AICounter2 = 0;
        int AICounter3 = 0;
        

        int targetHolderX;
        int targetHolderY;
        int targetHolderX2;
        int targetHolderY2;
        int actorHolderX;
        int actorHolderY;
        int actorHolderX2;
        int actorHolderY2;
        int targetNumberHolder;
        int targetNumberHolder2;
        
        int aiMoveCounter;
        int moveCounter;
        int cheatCounter;
        int correctBlocks;
        int gamesWon;

        int[,] highScores = new int[10,10];
        string[,] strHighscores = new string[10, 10];
        

        int solvingStage = 0;

        bool disabled = false;
        bool simulation = false;
        bool moveCompleted = false;
        bool loaded = false;
        bool cheatingAllowed = true;

        bool playing = false;

        string state = "idle";
        string performance = "high";

        public PrivateFontCollection myFonts;
        FontFamily family;
        Font captureBig;
        Font captureSmall;
        Font captureMedium;
        Font captureName;

        //Multi dimensional button array to hold button values and display the game.
        System.Windows.Forms.Button[,] btnArrayGlobal = new System.Windows.Forms.Button[11, 11];
        int[] loadedButtonValues;

        //Resource for opensave/load.
        OpenFileDialog fileSelect = new OpenFileDialog();

        public Form1()
        {
            InitializeComponent();

            family = LoadFontFamily("../Resources/captureIt.ttf", out myFonts);
            captureBig = new Font(family, 36.0f);
            captureSmall = new Font(family, 12.0f);
            captureMedium = new Font(family, 16.25f);
            captureName = new Font(family, 26.25f);

            //Loading Image resources.
            btnAddButton.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            btnCheat.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            btnLoad.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            btnSave.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            btnSimulate.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            btnClear.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            pnlLeftInterface.BackgroundImage = Image. FromFile("../Resources/interfaceLeft4.jpg");
            pnlBottomInterface.BackgroundImage = Image.FromFile("../Resources/interfaceBottom.jpg");
            pnlStats.BackgroundImage = Image.FromFile("../Resources/statusPanel.jpg");
            btnCheatToggle.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            btnHighScores.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            btnName.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            btnRandom.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            btnNameGood.BackgroundImage = Image.FromFile("../Resources/btn4.jpg");
            pnlMainScreen.BackgroundImage = Image.FromFile("../Resources/titleScreen.jpg");
            pnlNamePlate.BackgroundImage = Image.FromFile("../Resources/namePlate.jpg");
            

            
            
            //Set custom fonts to labels and buttons.
            lblCheatsUsed.Font = captureSmall;
            lblNamePlate.Font = captureBig;
            lblMoves.Font = captureSmall;
            lblNameSmall.Font = captureSmall;
            lblWins.Font = captureSmall;
            lblMenu.Font = captureBig;
            lblAIState.Font = captureSmall;
            lblColumns.Font = captureMedium;
            lblRows.Font = captureMedium;
            lblCheats.Font = captureSmall;
            lblEnterName.Font = captureMedium;
            lblLevel.Font = captureBig;
            lblLevelTitle.Font = captureMedium;
            txtBoxName.Font = captureName;
            txtBoxRows.Font = captureSmall;
            txtBoxColumns.Font = captureSmall;
            btnRandom.Font = captureSmall;
            btnHighScores.Font = captureSmall;
            btnCheatToggle.Font = captureSmall;
            btnName.Font = captureSmall;
            btnCheat.Font = captureMedium;
            btnClear.Font = captureMedium;
            btnLoad.Font = captureMedium;
            btnSimulate.Font = captureMedium;
            btnSave.Font = captureMedium;
            btnAddButton.Font = captureMedium;
            btnNameGood.Font = captureMedium;
            lblHighScores.Font = captureSmall;
;
            

            for (int i = 3; i < 10; i++ )
            {
                for (int x = 3; x<10; x++)
                {
                    highScores[i, x] = 10000;
                    strHighscores[i, x] = "Steve";
                }
            }



                idleState();
        }


        private FontFamily LoadFontFamily(string fileName, out PrivateFontCollection myFonts)
        {
            myFonts = new PrivateFontCollection();
            myFonts.AddFontFile(fileName);
            return myFonts.Families[0];
        }

        //Determine array length from selected rows and columns,
        //declare buttons with a for loop.
        private void AddButtons()
        {

            pnlButtonsMain.Visible = false;
            int xPos = 0;
            int yPos = 0;

            int arrayX = 1;
            int arrayY = 1;

            for (int i = 1; i < (rows * columns) + 2; i++)
            {

                btnArrayGlobal[arrayX, arrayY] = new System.Windows.Forms.Button();
                if (i == rows * columns)
                {
                    btnArrayGlobal[arrayX, arrayY].Visible = true;
                    btnArrayGlobal[arrayX, arrayY].Enabled = true;
                }
                if (i >= columns && i % columns == 0)
                {
                    arrayY++;
                    arrayX = 1;
                }
                else
                {
                    arrayX++;
                }
            }

            int n = 0;
            arrayX = 1;
            arrayY = 1;

            //Generate an array with numbers in random order to fill in the button array text.

            int[] HolderArray = new int[(rows * columns) - 1];

            for (int x = 0; x < HolderArray.Length; x++)
            {
                HolderArray[x] = x;
            }

            Random rnd = new Random();

            int[] MyRandomArray = HolderArray.OrderBy(x => rnd.Next()).ToArray();


            //Use rows and columns selection to generate the game buttons in a while loop.
            while (n < (rows * columns))
            {

                btnArrayGlobal[arrayX, arrayY].Tag = arrayX + " " + arrayY + " ";
                btnArrayGlobal[arrayX, arrayY].Width = 50;
                btnArrayGlobal[arrayX, arrayY].Height = 50;
                btnArrayGlobal[arrayX, arrayY].BackColor = Color.Black;
                btnArrayGlobal[arrayX, arrayY].FlatStyle = FlatStyle.Flat;
                btnArrayGlobal[arrayX, arrayY].Font = captureSmall;
                btnArrayGlobal[arrayX, arrayY].BackgroundImage = Image.FromFile("../Resources/btn5.jpg");

                // Set button location
                btnArrayGlobal[arrayX, arrayY].Left = xPos;
                btnArrayGlobal[arrayX, arrayY].Top = yPos;
                // Add buttons to Panel: 
                pnlButtonsMain.Controls.Add(btnArrayGlobal[arrayX, arrayY]);
                xPos = xPos + btnArrayGlobal[arrayX, arrayY].Width;

                // Write the random numbers to the button, except for the last one.
                // Use 100 for identification purposes on the blank button later.
                if (n == rows * columns - 1 || n == rows * columns && !loaded)
                {
                    btnArrayGlobal[arrayX, arrayY].Text = "100";
                }
                else if (!loaded)
                {
                    btnArrayGlobal[arrayX, arrayY].Text = MyRandomArray[n].ToString();
                }
                //If loaded is true, use the loaded array to populate button text values instead
                //of randomly generated array.
                if (loaded)
                {
                    btnArrayGlobal[arrayX, arrayY].Text = loadedButtonValues[n].ToString();
                }
                if (btnArrayGlobal[arrayX, arrayY].Text == "100")
                {
                    btnArrayGlobal[arrayX, arrayY].Visible = false;
                }


                // Create event handlers for the button clicks

                btnArrayGlobal[arrayX, arrayY].Click += new System.EventHandler(ClickButton);


                if ((n + 1) >= columns && (n + 1) % columns == 0)
                {
                    xPos = 0;
                    yPos += 55;
                }

                if ((n + 1) >= columns && (n + 1) % columns == 0)
                {
                    arrayY++;
                    arrayX = 1;
                }
                else
                {
                    arrayX++;
                }
                n++;

            }
            pnlButtonsMain.Visible = true;
            checkForWinner();
        }

        public void ClickButton(Object sender, System.EventArgs e)
        {
            if (!disabled)
            {

                string buttonX;
                string buttonY;
                int whiteSpace;

                var button = sender as Button;
                var theValueVar = button.Tag.ToString();

                int secondDigit;

                bool doubleDigit = Int32.TryParse(theValueVar[0 + 1].ToString(), out secondDigit);
                if (doubleDigit == true)
                {
                    buttonX = (theValueVar[0].ToString() + theValueVar[0 + 1].ToString());
                    whiteSpace = 2;
                }
                else
                {
                    buttonX = theValueVar[0].ToString();
                    whiteSpace = 1;
                }

                doubleDigit = Int32.TryParse(theValueVar[whiteSpace + 1].ToString(), out secondDigit);

                if (doubleDigit)
                {
                    buttonY = theValueVar[whiteSpace + 1].ToString() + theValueVar[whiteSpace + 2].ToString();
                }
                else
                {
                    buttonY = theValueVar[2].ToString();
                }

                int xValue = Convert.ToInt32(buttonX);
                int yValue = Convert.ToInt32(buttonY);
                int buttonCount = 0;

                bool moved = false;

                //Check all buttons underneath the one clicked to see if movement is available

                for (int i = 1; i <= (rows - (yValue)); i++)
                {
                    buttonCount++;
                    if (btnArrayGlobal[xValue, (yValue + i)].Text == "100" && !moved)
                    {

                        string direction = "down";
                        if (performance == "high")
                        {
                            simulateButtonMovement(xValue, yValue, buttonCount, direction);
                        }
                        for (int x = buttonCount; buttonCount > 0; buttonCount--)
                        {
                            btnArrayGlobal[xValue, (yValue + buttonCount)].Text = btnArrayGlobal[xValue, (yValue + buttonCount) - 1].Text;
                            btnArrayGlobal[xValue, (yValue + buttonCount)].Visible = true;
                            btnArrayGlobal[xValue, (yValue + buttonCount)].Enabled = true;
                        }
                        btnArrayGlobal[xValue, yValue].Text = "100";
                        btnArrayGlobal[xValue, yValue].Visible = false;
                        btnArrayGlobal[xValue, yValue].Enabled = true;
                        moved = true;
                        moveCompleted = true;
                    }
                }

                buttonCount = 0;

                //Check all buttons above the one clicked to check for potential movement

                if (!moved)
                {
                    for (int i = 1; i < yValue; i++)
                    {
                        buttonCount++;
                        if (btnArrayGlobal[xValue, (yValue - i)].Text == "100" && !moved)
                        {
                            string direction = "up";
                            if (performance == "high")
                            {
                                simulateButtonMovement(xValue, yValue, buttonCount, direction);
                            }
                            for (int x = buttonCount; buttonCount > 0; buttonCount--)
                            {
                                btnArrayGlobal[xValue, (yValue - buttonCount)].Text = btnArrayGlobal[xValue, (yValue - buttonCount) + 1].Text;
                                btnArrayGlobal[xValue, (yValue - buttonCount)].Visible = true;
                                btnArrayGlobal[xValue, (yValue - buttonCount)].Enabled = true;

                            }
                            btnArrayGlobal[xValue, yValue].Text = "100";
                            btnArrayGlobal[xValue, yValue].Visible = false;
                            btnArrayGlobal[xValue, yValue].Enabled = true;
                            buttonCount = 0;
                            moved = true;
                            moveCompleted = true;
                        }
                    }
                }

                buttonCount = 0;

                //Check all buttons to the left of the one clicked to check for potential movement.

                if (!moved)
                {
                    for (int i = 1; i < xValue; i++)
                    {
                        buttonCount++;
                        if (btnArrayGlobal[xValue - i, (yValue)].Text == "100" && !moved)
                        {
                            string direction = "left";
                            if (performance == "high")
                            {
                                simulateButtonMovement(xValue, yValue, buttonCount, direction);
                            }
                            for (int x = buttonCount; buttonCount > 0; buttonCount--)
                            {
                                btnArrayGlobal[(xValue - buttonCount), yValue].Text = btnArrayGlobal[((xValue - buttonCount) + 1), yValue].Text;
                                btnArrayGlobal[(xValue - buttonCount), yValue].Visible = true;
                                btnArrayGlobal[(xValue - buttonCount), yValue].Enabled = true;

                            }
                            btnArrayGlobal[xValue, yValue].Text = "100";
                            btnArrayGlobal[xValue, yValue].Visible = false;
                            btnArrayGlobal[xValue, yValue].Enabled = true;
                            buttonCount = 0;
                            moved = true;
                            moveCompleted = true;
                        }
                    }
                }

                buttonCount = 0;

                //Check all buttons to the left of the one clicked to check for potential movement.
                if (!moved)
                {
                    for (int i = 1; i <= (columns - xValue); i++)
                    {
                        buttonCount++;
                        if (btnArrayGlobal[xValue + i, (yValue)].Text == "100" && !moved)
                        {
                            string direction = "right";
                            if (performance == "high")
                            {
                                simulateButtonMovement(xValue, yValue, buttonCount, direction);
                            }
                            for (int x = buttonCount; buttonCount > 0; buttonCount--)
                            {
                                btnArrayGlobal[(xValue + buttonCount), yValue].Text = btnArrayGlobal[((xValue + buttonCount) - 1), yValue].Text;
                                btnArrayGlobal[(xValue + buttonCount), yValue].Visible = true;
                                btnArrayGlobal[(xValue + buttonCount), yValue].Enabled = true;

                            }
                            btnArrayGlobal[xValue, yValue].Text = "100";
                            btnArrayGlobal[xValue, yValue].Visible = false;
                            btnArrayGlobal[xValue, yValue].Enabled = true;
                            buttonCount = 0;
                            moved = true;
                            moveCompleted = true;
                        }
                    }
                }

                int arrayY = 1;
                int arrayX = 1;

                //Re-enable all the buttons after the move
                for (int i = 0; i < columns * rows; i++)
                {

                    disabled = false;

                    if ((i + 1) >= columns && (i + 1) % columns == 0)
                    {
                        arrayY++;
                        arrayX = 1;
                    }
                    else
                    {
                        arrayX++;
                    }
                }
                moveCounter++;
                lblMoves.Text = "Moves:   " + moveCounter.ToString();
                checkForWinner();
            }
        }

        private void simulateButtonMovement(int xValue, int yValue, int buttonCount, string direction)
        {
            
          
            int arrayY = 1;
            int arrayX = 1;
            int n = 0; ;
            int y3;
            int y5;
            

            //Disable all buttons
            for (int i = 0; i < columns * rows; i++)
            {

                disabled = true;

                if ((i + 1) >= columns && (i + 1) % columns == 0)
                {
                    arrayY++;
                    arrayX = 1;
                }
                else
                {
                    arrayX++;
                }
            }

            //Move all effected buttons while they are disabled
            switch (performance)
            {
                case "high":
                    {
                        n = 0;
                        break;
                    }
            }

            switch (direction)
            {
                case "down":
                    {
                        while (n <= 10)
                        {
                            for (int i = 0; i < buttonCount; i++)
                            {
                                btnArrayGlobal[xValue, (yValue + i)].Location = new Point(btnArrayGlobal[xValue, (yValue + i)].Left, btnArrayGlobal[xValue, (yValue + i)].Top + 5);
                                Application.DoEvents();
                                System.Threading.Thread.Sleep(1);
                            }
                            n++;
                            Application.DoEvents();
                            System.Threading.Thread.Sleep(1);
                        }
                        for (int i = 0; i < buttonCount; i++)
                        {
                            btnArrayGlobal[xValue, (yValue + i)].Location = new Point(btnArrayGlobal[xValue, (yValue + i)].Left, btnArrayGlobal[xValue, (yValue + i)].Top - 55);
                        }
                        break;
                    }
                case "up":
                    {
                        while (n <= 10)
                        {
                            for (int i = 0; i < buttonCount; i++)
                            {
                                btnArrayGlobal[xValue, (yValue - i)].Location = new Point(btnArrayGlobal[xValue, (yValue - i)].Left, btnArrayGlobal[xValue, (yValue - i)].Top - 5);
                                Application.DoEvents();
                                System.Threading.Thread.Sleep(1);
                            }
                            n++;
                        }
                        for (int i = 0; i < buttonCount; i++)
                        {
                            btnArrayGlobal[xValue, (yValue - i)].Location = new Point(btnArrayGlobal[xValue, (yValue - i)].Left, btnArrayGlobal[xValue, (yValue - i)].Top + 55);
                        }
                        break;
                    }
                case "left":
                    {
                        while (n <= 9)
                        {
                            for (int i = 0; i < buttonCount; i++)
                            {
                                btnArrayGlobal[(xValue - i), yValue].Location = new Point(btnArrayGlobal[(xValue - i), yValue].Left - 5, btnArrayGlobal[xValue - i, yValue].Top);
                                Application.DoEvents();
                                System.Threading.Thread.Sleep(1);
                            }
                            n++;
                        }
                        for (int i = 0; i < buttonCount; i++)
                        {
                            btnArrayGlobal[(xValue - i), yValue].Location = new Point(btnArrayGlobal[(xValue - i), yValue].Left + 50, btnArrayGlobal[xValue - i, (yValue)].Top);
                        }
                        break;
                    }
                case "right":
                    {
                        while (n <= 9)
                        {
                            for (int i = 0; i < buttonCount; i++)
                            {
                                btnArrayGlobal[(xValue + i), yValue].Location = new Point(btnArrayGlobal[(xValue + i), yValue].Left + 5, btnArrayGlobal[xValue + i, yValue].Top);
                                Application.DoEvents();
                                System.Threading.Thread.Sleep(1);
                            }
                            n++;
                        }
                        for (int i = 0; i < buttonCount; i++)
                        {
                            btnArrayGlobal[(xValue + i), yValue].Location = new Point(btnArrayGlobal[(xValue + i), yValue].Left - 50, btnArrayGlobal[xValue + i, (yValue)].Top);
                        }
                        break;
                    }
            }

        }

        //Check every index of the array from start to finish looking for incrementing numbers, if they increment all
        //the way to the end, the player has won.
        private void checkForWinner()
        {
            int counterX = 1;
            int counterY = 1;
            int neededToWin = ((rows * columns) - 2);
            int numberStreak = 0;
            int testStreak;
            int testStreak2;

            for (int i = 0; i < (neededToWin); i++)
            {


                if (btnArrayGlobal[counterX, counterY].Text != "100")
                {
                    testStreak = Convert.ToInt32(btnArrayGlobal[counterX, counterY].Text);

                }
                else
                {
                    testStreak = 0;
                }

                if (counterX != columns)
                {
                    counterX++; ;
                }
                else
                {
                    counterX = 1;
                    counterY++;
                }

                if (btnArrayGlobal[counterX, counterY].Text != "100")
                {
                    testStreak2 = Convert.ToInt32(btnArrayGlobal[counterX, counterY].Text);

                    if (testStreak2 == (testStreak + 1) && numberStreak == i)
                    {
                        numberStreak++;
                        btnArrayGlobal[counterX, counterY].BackColor = Color.Crimson;
                        btnArrayGlobal[counterX, counterY].BackgroundImage = Image.FromFile("../Resources/btn6.jpg");
                        correctBlocks = numberStreak;
                    }
                    if (numberStreak < i)
                    {
                        btnArrayGlobal[counterX, counterY].BackColor = Color.Black;
                    }
                }
                if (btnArrayGlobal[1, 1].Text == "0")
                {
                    btnArrayGlobal[1, 1].BackgroundImage = Image.FromFile("../Resources/btn6.jpg");
                }



                if (numberStreak == neededToWin && btnArrayGlobal[1, 1].Text == "0")
                {
                    simulation = false;
                    lblAIState.Text = "A.I:          OFF";
                    MessageBox.Show("You won the game!");
                    gamesWon++;
                    lblWins.Text = "Wins:   " + gamesWon;

                    if (moveCounter < highScores[columns, rows])
                    {
                        highScores[columns, rows] = moveCounter;
                        strHighscores[columns, rows] = name;
                        MessageBox.Show("New Highscore!");
                    }                  
                    
                    i++;
                    clearScreen();
                    idleState();
                    AICounter = 0;
                    AICounter2 = 0;
                    break;
                }
            }
        }

        //Enable / disable controls outside of the game.
        private void idleState()
        {
            if (state != "idle")
            {
                pnlMainScreen.BackgroundImage = Image.FromFile("../Resources/titleScreen.jpg");
            }
            pnlMenuWindow.BackgroundImage = Image.FromFile("../Resources/menuWindow.jpg");
            pnlMenuWindow.Visible = true;
            pnlMenuWindow.Enabled = true;
            pnlButtonsMain.Visible = false;
            pnlMenuWindow.Visible = true;
            pnlMenuWindow.Enabled = true;
            btnAddButton.Visible = true;
            btnAddButton.Enabled = true;
            btnClear.Visible = false;
            btnClear.Enabled = false;
            btnCheat.Enabled = false;
            btnLoad.Enabled = true;
            btnName.Visible = true;
            btnName.Enabled = true;
            btnNameGood.Visible = false;
            btnNameGood.Enabled = false;
            btnHighScores.Visible = true;
            btnHighScores.Enabled = true;
            btnCheatToggle.Visible = true;
            btnCheatToggle.Enabled = true;
            btnRandom.Enabled = true;
            btnRandom.Visible = true;


            txtBoxColumns.Visible = true;
            txtBoxRows.Visible = true;
            txtBoxColumns.Enabled = true;
            txtBoxRows.Enabled = true;
            txtBoxName.Enabled = false;
            txtBoxName.Visible = false;
            lblColumns.Visible = true;
            lblRows.Visible = true;
            lblEnterName.Visible = false;
            lblEnterName.Visible = false;
            btnSimulate.Enabled = false;

            lblLevel.Text = "";

            //cBoxTitle.Visible = true;

            playing = false;
            loaded = false;

            state = "idle";

            //playDemo();


        }

        //private void playDemo()
        //{

        //    int xPos = 0;
        //    int yPos = 0;

        //    int arrayX = 1;
        //    int arrayY = 1;

        //    pnlButtonsMain.Size = new Size(200, 220);
        //    pnlButtonsMain.Location = new Point(358, 193);



        //    for (int i = 1; i <= 16; i++)
        //    {

        //        btnArrayGlobal[arrayX, arrayY] = new System.Windows.Forms.Button();

        //        btnArrayGlobal[arrayX, arrayY].Visible = true;
        //        btnArrayGlobal[arrayX, arrayY].Enabled = true;

        //        if (i == 16)
        //        {
        //            btnArrayGlobal[arrayX, arrayY].Visible = false;
        //        }

        //        if (i == 4 || i == 8 || i == 12)
        //        {
        //            arrayY++;
        //            arrayX = 1;
        //        }
        //        else
        //        {
        //            arrayX++;
        //        }
        //    }

        //    int n = 1;
        //    arrayX = 1;
        //    arrayY = 1;

        //    while (n <= 16)
        //    {
        //        btnArrayGlobal[arrayX, arrayY].Width = 50;
        //        btnArrayGlobal[arrayX, arrayY].Height = 50;
        //        btnArrayGlobal[arrayX, arrayY].BackColor = Color.DarkGray;

        //        // Determine button location
        //        btnArrayGlobal[arrayX, arrayY].Left = xPos;
        //        btnArrayGlobal[arrayX, arrayY].Top = yPos;
        //        // Add buttons to a Panel: 
        //        pnlButtonsMain.Controls.Add(btnArrayGlobal[arrayX, arrayY]);
        //        xPos = xPos + btnArrayGlobal[arrayX, arrayY].Width;


        //        if (n == 4 || n == 8 || n == 12)
        //        {
        //            xPos = 0;
        //            yPos += 55;
        //        }

        //        if (n == 4 || n == 8 || n == 12)
        //        {
        //            arrayY++;
        //            arrayX = 1;
        //        }
        //        else
        //        {
        //            arrayX++;
        //        }
        //        n++; 
        //    }
        //}

        //MAke sure row/column inputs are valid, check to see if row / column has been loaded from save file.
        private void btnAddButton_Click(object sender, EventArgs e)
        {
            bool rowIsNumeric;
            bool columnIsNumeric;
            cheatCounter = 0;
            moveCounter = 0;
            lblCheatsUsed.Text = "Cheats: ";
            lblMoves.Text = "Moves: ";

            if (!loaded)
            {
                rowIsNumeric = Int32.TryParse(txtBoxRows.Text, out rows);
                columnIsNumeric = Int32.TryParse(txtBoxColumns.Text, out columns);
            }
            else
            {
                rowIsNumeric = true;
                columnIsNumeric = true;
            }

            if (rowIsNumeric && columnIsNumeric)
            {
                if (rows < 11 && columns < 11 && Convert.ToInt32(rows) > 1 && Convert.ToInt32(columns) > 1)
                {
                    AddButtons();
                    gameState();
                    resizeWindow();
                }
                else
                {
                    MessageBox.Show("Please enter only numbers between 3 and ten in the generation fields.");
                }
            }
            else
            {
                MessageBox.Show("Please enter only numbers between 3 and ten in the generation fields.");
                clearScreen();
            }

        }

        private void destroyDemoArray()
        {
            int n = 0;
            int arrayX = 1;
            int arrayY = 1;

            //Use while loop to delete all active buttons in the array.
            while (n < (16))
            {
                Controls.Remove(btnArrayGlobal[arrayX, arrayY]);
                btnArrayGlobal[arrayX, arrayY].Dispose();

                if ((n + 1) == 4 || (n + 1) == 8 || (n + 1) == 12)
                {
                    arrayY++;
                    arrayX = 1;
                }
                else
                {
                    arrayX++;
                }
                n++;
            }
        }

        //Enables and disables controls based on game state.

        private void gameState()
        {
            state = "game";
            pnlMainScreen.BackgroundImage = Image.FromFile("../Resources/playScreen.jpg");
            pnlButtonsMain.Visible = true;
            pnlMenuWindow.Visible = false;
            pnlMenuWindow.Enabled = false;
            btnAddButton.Enabled = false;
            btnAddButton.Visible = false;
            btnCheat.Enabled = true;
            btnClear.Visible = true;
            btnClear.Enabled = true;
            btnSave.Enabled = true;
            txtBoxColumns.Enabled = false;
            txtBoxRows.Enabled = false;
            btnSimulate.Enabled = true;
            lblLevel.Text = " " + rows + " , " + columns;
            //destroyDemoArray();

            playing = true;
        }

        //Calculates the size and location of the panel containing the buttons, based on how many columns and rows are chosen.
        private void resizeWindow()
        {
            if (rows > 0 && columns > 0)
            {
                pnlButtonsMain.Size = new Size(columns * 50, rows * 55);
                pnlButtonsMain.Location = new Point(((671 - (columns * 55)) / 2), ((700 - (rows * 55)) / 2) - 70);


            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearScreen();
            idleState();
        }

        //Clears objects and inputed information from the screen.
        private void clearScreen()
        {
            int n = 0;
            int arrayX = 1;
            int arrayY = 1;

            //Use while loop to delete all active buttons in the array.
            while (n < (rows * columns))
            {
                Controls.Remove(btnArrayGlobal[arrayX, arrayY]);
                btnArrayGlobal[arrayX, arrayY].Dispose();

                if ((n + 1) >= columns && (n + 1) % columns == 0)
                {
                    arrayY++;
                    arrayX = 1;
                }
                else
                {
                    arrayX++;
                }
                n++;
                pnlButtonsMain.BackColor = Color.Black;
            }

            txtBoxColumns.Clear();
            txtBoxRows.Clear();
            AICounter = 0;
            AICounter2 = 0;
        }

        //SAveFileDialogue file saving resource class.
        //Set attributes, declare the variables i would like to save,
        //concat them and save to text file.
        private void btnSave_Click(object sender, EventArgs e)
        {

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.InitialDirectory = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Application.ExecutablePath), @"saveFiles");
            saveFileDialog1.Title = "Save text Files";
            saveFileDialog1.CreatePrompt = true;
            saveFileDialog1.OverwritePrompt = true;
            saveFileDialog1.CheckPathExists = true;
            saveFileDialog1.DefaultExt = "txt";
            saveFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string storedData = columns + "," + rows;
                int totalButtons = (columns * rows);
                loadedButtonValues = recordButtonValues();
                storedData = buildDataString(storedData);




                StreamWriter streamWriter = new StreamWriter(saveFileDialog1.FileName);
                streamWriter.Write(storedData);
                streamWriter.Close();
            }

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            if (fileSelect.ShowDialog() == DialogResult.OK)
            {
                //Check if file is alraedy in folder
                if (File.Exists(fileSelect.FileName))
                {
                    //Close the StreamReader Resource file
                    using (StreamReader fileReader = new StreamReader(fileSelect.FileName))
                    {
                        //Write everything to a string, then split it up into separate elemments and put them in an array.
                        string inputrecord = fileReader.ReadLine();
                        string[] inputFields;

                        //Continue to add items to the array until a null value is found.
                        if (inputrecord != null)
                        {
                            inputFields = inputrecord.Split(',');
                            columns = Convert.ToInt32(inputFields[0]);
                            rows = Convert.ToInt32(inputFields[1]);

                            int counterX = 1;
                            int counterY = 1;

                            //Create an array with all my button values so i can iterate through them and add them to buttons later.
                            loadedButtonValues = new int[columns * rows];

                            for (int i = 0; i < (columns * rows); i++)
                            {
                                loadedButtonValues[i] = Convert.ToInt32(inputFields[i + 2]);

                                if (counterX != columns)
                                {
                                    counterX++;
                                }
                                else
                                {
                                    counterX = 1;
                                    counterY++;
                                }
                            }
                        }
                    }
                }
                loaded = true;
                btnAddButton.PerformClick();
            }
        }

        private string buildDataString(string storedData)
        {
            int counterX = 1;
            int counterY = 1;


            for (int i = 0; i < (columns * rows); i++)
            {
                storedData = storedData + "," + loadedButtonValues[i];

                if (counterX != columns)
                {
                    counterX++;
                }
                else
                {
                    counterX = 1;
                    counterY++;
                }
            }

            return storedData;
        }

        private int[] recordButtonValues()
        {
            int counterX = 1;
            int counterY = 1;

            int[] buttonValues = new int[columns * rows];

            for (int i = 0; i < (columns * rows); i++)
            {
                buttonValues[i] = Convert.ToInt32(btnArrayGlobal[counterX, counterY].Text);

                if (counterX != columns)
                {
                    counterX++;
                }
                else
                {
                    counterX = 1;
                    counterY++;
                }
            }

            return buttonValues;
        }

        private void btnCheat_Click(object sender, EventArgs e)
        {
            string valueHolder;
            int wrongButtonX;
            int wrongButtonY;
            int counterX = 1;
            int counterY = 1;

            if (cheatingAllowed)
            {

                AICounter = 0;
                AICounter2 = 0;
                moveCounter += 100;
                cheatCounter += 1;
                lblCheatsUsed.Text = "Cheats:   " + cheatCounter;
                lblMoves.Text = "Moves:   " + moveCounter;

                int maxButtons = (rows * columns - 1);

                if (btnArrayGlobal[1, 1].Text == "0")
                {
                    for (int i = 0; i < (maxButtons); i++)
                    {
                        if (Convert.ToInt32(btnArrayGlobal[counterX, counterY].Text) != i)
                        {
                            wrongButtonX = counterX;
                            wrongButtonY = counterY;
                            valueHolder = btnArrayGlobal[counterX, counterY].Text;

                            for (int x = 0; x < (maxButtons); x++)
                            {
                                if (Convert.ToInt32(btnArrayGlobal[counterX, counterY].Text) == i)
                                {
                                    btnArrayGlobal[wrongButtonX, wrongButtonY].Text = btnArrayGlobal[counterX, counterY].Text;
                                    btnArrayGlobal[counterX, counterY].Text = valueHolder;
                                    x = maxButtons;
                                    i = maxButtons;

                                    if (btnArrayGlobal[wrongButtonX, wrongButtonY].Visible == false)
                                    {
                                        btnArrayGlobal[wrongButtonX, wrongButtonY].Visible = true;
                                        btnArrayGlobal[counterX, counterY].Visible = false;
                                    }
                                }

                                else
                                {
                                    if (counterX != columns)
                                    {
                                        counterX++;
                                    }
                                    else
                                    {
                                        counterX = 1;
                                        counterY++;
                                    }
                                }
                            }
                        }

                        else
                        {
                            if (counterX != columns)
                            {
                                counterX++;
                            }
                            else
                            {
                                counterX = 1;
                                counterY++;
                            }
                        }
                    }
                }

                else if ((btnArrayGlobal[1, 1].Text == "100"))
                {
                    for (int i = 0; i < (maxButtons); i++)
                    {
                        if (Convert.ToInt32(btnArrayGlobal[counterX, counterY].Text) == 0)
                        {
                            valueHolder = btnArrayGlobal[1, 1].Text;
                            btnArrayGlobal[1, 1].Text = btnArrayGlobal[counterX, counterY].Text;
                            btnArrayGlobal[1, 1].Visible = true;
                            btnArrayGlobal[counterX, counterY].Text = valueHolder;
                            btnArrayGlobal[counterX, counterY].Visible = false;
                        }
                        if (counterX != columns)
                        {
                            counterX++;
                        }
                        else
                        {
                            counterX = 1;
                            counterY++;
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < (maxButtons); i++)
                    {
                        if (Convert.ToInt32(btnArrayGlobal[counterX, counterY].Text) == 0)
                        {
                            valueHolder = btnArrayGlobal[1, 1].Text;
                            btnArrayGlobal[1, 1].Text = btnArrayGlobal[counterX, counterY].Text;
                            btnArrayGlobal[counterX, counterY].Text = valueHolder;
                        }
                        if (counterX != columns)
                        {
                            counterX++;
                        }
                        else
                        {
                            counterX = 1;
                            counterY++;
                        }
                    }
                }
                checkForWinner();
            }
        }

        //Simulation AI Logic for automated play
        private void btnSimulate_Click(object sender, EventArgs e)
        {
            if (simulation == true)
            {
                simulation = false;
                btnSimulate.BackColor = Color.Black;
                lblAIState.Text = "A.I.:        OFF";
                aiMoveCounter = 0;
            }
            else
            {
                simulation = true;
                btnSimulate.BackColor = Color.Black;
                lblAIState.Text = "A.I.:         ON";
                aiMoveCounter = 0;
                AISolver();
            }
        }

        private void reloadButtonEvents()
        {
            int arrayX = 1;
            int arrayY = 1;

            for (int i = 1; i < (rows * columns); i++)
            {
                RemoveClickEvent(btnArrayGlobal[arrayX, arrayY]);
                btnArrayGlobal[arrayX, arrayY].Click += new System.EventHandler(ClickButton);

                if (i >= columns && i % columns == 0)
                {
                    arrayY++;
                    arrayX = 1;
                }
                else
                {
                    arrayX++;
                }
            }
            Application.DoEvents();
            System.Threading.Thread.Sleep(10);
        }
    


        //Unsubscribe button event handlers to help clean overflow stack
        //Reference: http://stackoverflow.com/questions/91778/how-to-remove-all-event-handlers-from-a-control

        private void RemoveClickEvent(Button currentButton)
        {
            FieldInfo buttonInfo = typeof(Control).GetField("EventClick", BindingFlags.Static | BindingFlags.NonPublic);
            object obj = buttonInfo.GetValue(currentButton);
            PropertyInfo currentProperties = currentButton.GetType().GetProperty("Events", BindingFlags.NonPublic | BindingFlags.Instance);
            EventHandlerList list = (EventHandlerList)currentProperties.GetValue(currentButton, null);
            list.RemoveHandler(obj, list[obj]);
        }
        
        //Attempt to write a puzzle solving AI. Solves up to the last 2 rows. Began working on logic for last 2 rows
        //but lost interest. If left running will crash due to stack overflow likely from too many nested if statements.
        //Was in the process of cleaning it up, breaking the function into small pieces with exit points, but lost interest
        //there as well.

        //Will leave this section uncommented for the most part as it is not worth marks and I just wanted to see if I could do it.
        private void AISolver()
        {

            while (correctBlocks < columns * rows)
            {
                bool[,] validMoves = new bool[4, 4];
                bool[,] validMoves2 = new bool[4, 4];

                bool blankBeside = false;
                bool blankBeside2 = false;

                bool moved = false;

                bool movingLeft = false;
                bool movingUp = false;
                bool movingDown = false;
                bool movingRight = false;


                int targetX2;
                int targetY2;
                int actorBlockX2 = 0;
                int actorBlockY2 = 0;

                int targetNumber2 = 0;

                string condensedData;

                moveCompleted = false;

                if (correctBlocks > (columns * rows) - (rows * 2))
                {
                    simulation = false;
                }

                if (simulation)
                {

                    //Find the target we need to get to.
                    condensedData = findTargetToMoveTo();

                    //Extract the 3 values found in target method from a concatted string.
                    int targetX = extractCondensedVariables(condensedData, 0);
                    int targetY = extractCondensedVariables(condensedData, 1);
                    int targetNumber = extractCondensedVariables(condensedData, 2);

                    //Locate the block we want to move
                    condensedData = findActorBlock(targetNumber);
                    int actorBlockX = extractCondensedVariables(condensedData, 0);
                    int actorBlockY = extractCondensedVariables(condensedData, 1);

                    //Locate the blank space that actor blocks can interact with for movement.
                    condensedData = findBlankSpace();
                    int blankSpaceX = extractCondensedVariables(condensedData, 0);
                    int blankSpaceY = extractCondensedVariables(condensedData, 1);

                    //Determine AI logic for puzzle solving stage.
                    solvingStage = determineSolvingLogic(actorBlockX, actorBlockY, targetX, targetY);

                    //Adjust solution strategy based on puzzle solving stage.
                    condensedData = adjustStrategy(targetX, targetY, actorBlockX, actorBlockY, targetNumber, targetNumber2, actorBlockX2, actorBlockY2);

                    //incomplete solving logic for last 2 rows.

                    //if (solvingStage >= 1)
                    //{
                    //    if (AICounter3 == 0)
                    //    {
                    //        //targetHolderX = (1 + solvingStage);
                    //        //targetHolderY = (rows - 1);
                    //        //targetHolderX2 = 2 + solvingStage;
                    //        //targetHolderY2 = (rows - 1);
                    //        //actorHolderX = extractCondensedVariables(condensedData, 2);
                    //        //actorHolderY = extractCondensedVariables(condensedData, 3);
                    //        //actorHolderX2 = extractCondensedVariables(condensedData, 0);
                    //        //actorHolderY2 = extractCondensedVariables(condensedData, 1);
                    //        //validMoves = checkValidSquares(validMoves, actorHolderX, actorHolderY);
                    //        //validMoves2 = checkValidSquares(validMoves2, actorHolderX2, actorHolderY2);
                    //        //blankBeside = checkForBlankSpace(actorHolderX, actorHolderY, validMoves);
                    //        //blankBeside2 = checkForBlankSpace(actorHolderX2, actorHolderY2, validMoves2);
                    //        //AICounter3 = 1;
                    //    }

                    //    bool correctOrientation = true;

                    //    if (actorHolderX >= actorHolderX2)
                    //    {
                    //        correctOrientation = false;
                    //    }

                    //    if (AICounter3 == 1)
                    //    {
                    //        putActorOnTarget2(validMoves, validMoves2, blankSpaceX, blankSpaceY, correctOrientation, blankBeside, blankBeside2);
                    //        moved = true;
                    //    }
                    //    //if (AICounter2 > 1 && !moved)
                    //    //{
                    //    //    actorBlockX = actorHolderX;
                    //    //    actorBlockY = actorHolderY;
                    //    //    targetX = targetHolderX;
                    //    //    targetY = targetHolderY;
                    //    //    putActorOnTarget(validMoves, targetX, targetY, actorBlockX, actorBlockY, blankSpaceX, blankSpaceY);
                    //    //    moved = true;
                    //    //}

                    //}

                    //Check to see if blank space is beside ActorBlock, and check which moves are valid.
                    validMoves = checkValidSquares(validMoves, actorBlockX, actorBlockY);
                    blankBeside = checkForBlankSpace(actorBlockX, actorBlockY, validMoves);


                    if (targetX < actorBlockX)
                    {
                        movingLeft = true;
                    }
                    else if (targetX > actorBlockX)
                    {
                        movingRight = true;
                    }
                    if (targetY < actorBlockY)
                    {
                        movingUp = true;
                    }
                    else if (targetY > actorBlockY)
                    {
                        movingDown = true;
                    }


                    if (AICounter2 == 0 && blankSpaceX == columns && blankSpaceY == targetY)
                    {
                        btnArrayGlobal[columns, rows].PerformClick();
                        moved = true;
                    }


                    //Employ new logic for placing tiles for the last 2 columns in a row
                    if (solvingStage == 0)
                    {
                        if (targetX == actorBlockX && targetY == actorBlockY - 1 && blankBeside && AICounter2 == 0)
                        {
                            AICounter2 = 1;
                        }
                        if (AICounter2 == 1)
                        {
                            putActorOnTarget(validMoves, targetX, targetY, actorBlockX, actorBlockY, blankSpaceX, blankSpaceY);
                            moved = true;
                        }
                        if (AICounter2 > 1 && !moved)
                        {
                            actorBlockX = actorHolderX;
                            actorBlockY = actorHolderY;
                            targetX = targetHolderX;
                            targetY = targetHolderY;
                            putActorOnTarget(validMoves, targetX, targetY, actorBlockX, actorBlockY, blankSpaceX, blankSpaceY);
                            moved = true;
                        }
                    }
                    //else if (solvingStage == 2)
                    //{
                    //    randomizeInput(validMoves, targetX, targetY, actorBlockX, actorBlockY, actorBlockX2, actorBlockY2, blankSpaceX, blankSpaceY);
                    //}

                    //fillTextBoxDebug(actorBlockX, actorBlockY, targetX, targetY, blankSpaceX, blankSpaceY, targetNumber, blankBeside, solvingStage, targetNumber2);


                    if (!blankBeside)
                    {
                        if (movingLeft == true || movingRight == true && !moved)
                        {
                            if (actorBlockY != blankSpaceY && blankSpaceX == columns)
                            {
                                if (btnArrayGlobal[blankSpaceX - 1, blankSpaceY].BackColor != Color.Crimson)
                                {
                                    btnArrayGlobal[blankSpaceX - 1, blankSpaceY].PerformClick();
                                    moved = true;
                                }
                                else if (btnArrayGlobal[blankSpaceX, blankSpaceY + 1].BackColor != Color.Crimson && !moved)
                                {
                                    btnArrayGlobal[blankSpaceX, blankSpaceY + 1].PerformClick();
                                    moved = true;
                                }
                            }
                            else if (actorBlockY != blankSpaceY && btnArrayGlobal[blankSpaceX, actorBlockY].BackColor != Color.Crimson && !moved)
                            {
                                btnArrayGlobal[blankSpaceX, actorBlockY].PerformClick();
                                moved = true;
                            }
                            else if (btnArrayGlobal[actorBlockX, actorBlockY].BackColor != Color.Crimson && !moved)
                            {
                                btnArrayGlobal[actorBlockX, actorBlockY].PerformClick();
                                moved = true;
                            }
                        }

                        if (movingUp == true || movingDown == true && !moved)
                        {
                            if (actorBlockY == rows && blankSpaceY == rows)
                            {
                                if (btnArrayGlobal[blankSpaceX, blankSpaceY - 1].BackColor != Color.Crimson)
                                {
                                    btnArrayGlobal[blankSpaceX, blankSpaceY - 1].PerformClick();
                                    moved = true;
                                }
                                if (blankSpaceX != 1)
                                {
                                    if (btnArrayGlobal[blankSpaceX - 1, blankSpaceY].BackColor != Color.Crimson && !moved)
                                    {
                                        btnArrayGlobal[blankSpaceX - 1, blankSpaceY].PerformClick();
                                        moved = true;
                                    }
                                }
                                
                            }
                            else if (targetY != actorBlockY && !moved)
                            {
                                if (actorBlockX != blankSpaceX && blankSpaceY == 1 && btnArrayGlobal[blankSpaceX, blankSpaceY + 1].BackColor != Color.Crimson)
                                {
                                    btnArrayGlobal[blankSpaceX, blankSpaceY + 1].PerformClick();
                                    moved = true;
                                }
                                else if (actorBlockX != blankSpaceX && btnArrayGlobal[actorBlockX, blankSpaceY].BackColor != Color.Crimson && !moved)
                                {
                                    btnArrayGlobal[actorBlockX, blankSpaceY].PerformClick();
                                    moved = true;
                                }
                                else
                                {
                                    if (!moved)
                                    {
                                        btnArrayGlobal[actorBlockX, actorBlockY].PerformClick();
                                        moved = true;
                                    }

                                }
                            }
                        }
                        //No blank space beside and X is = to target... 
                        else
                        {

                        }
                    }
                    else if (blankBeside)
                    {
                        if (movingLeft && !moved)
                        {
                            if (validMoves[1, 2] == true)
                            {
                                if (btnArrayGlobal[actorBlockX - 1, actorBlockY].Text == "100")
                                {
                                    btnArrayGlobal[actorBlockX, actorBlockY].PerformClick();
                                    moved = true;
                                }
                            }
                            if ((validMoves[1, 1] == true) && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX - 1, actorBlockY - 1].Text == "100")
                                {
                                    if (btnArrayGlobal[actorBlockX - 1, actorBlockY].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX - 1, actorBlockY].PerformClick();
                                        moved = true;
                                    }
                                }
                                else if (blankSpaceX >= (actorBlockX) && blankSpaceY == (actorBlockY - 1) && !moved)
                                {
                                    btnArrayGlobal[actorBlockX - 1, actorBlockY - 1].PerformClick();
                                    moved = true;
                                }
                            }
                            if (validMoves[1, 3] == true && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX - 1, actorBlockY + 1].Text == "100")
                                {
                                    if (btnArrayGlobal[actorBlockX - 1, actorBlockY].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX - 1, actorBlockY].PerformClick();
                                        moved = true;
                                    }
                                }
                                else if (blankSpaceX >= (actorBlockX) && blankSpaceY == (actorBlockY + 1) && !moved)
                                {
                                    btnArrayGlobal[actorBlockX - 1, actorBlockY + 1].PerformClick();
                                    moved = true;
                                }
                            }
                            if (validMoves[3, 2] == true && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX + 1, actorBlockY].Text == "100")
                                {
                                    if (validMoves[3, 1] == true && !moved && btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].PerformClick();
                                        moved = true;
                                    }
                                    else if (validMoves[3, 3] == true && !moved)
                                    {
                                        btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].PerformClick();
                                        moved = true;
                                    }
                                }

                            }

                        }

                        if (movingRight && !moved)
                        {
                            if (validMoves[3, 2] == true && !moved)
                            {

                                if (btnArrayGlobal[actorBlockX + 1, actorBlockY].Text == "100")
                                {
                                    btnArrayGlobal[actorBlockX, actorBlockY].PerformClick();
                                    moved = true;
                                }
                            }
                            if ((validMoves[3, 3] == true) && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].Text == "100")
                                {
                                    if (btnArrayGlobal[actorBlockX + 1, actorBlockY].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX + 1, actorBlockY].PerformClick();
                                        moved = true;
                                    }
                                }
                                else if (blankSpaceX <= (actorBlockX) && blankSpaceY == (actorBlockY + 1))
                                {
                                    if (btnArrayGlobal[actorBlockX + 1, actorBlockY].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].PerformClick();
                                        moved = true;
                                    }

                                }
                            }
                            if ((validMoves[3, 1] == true) && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].Text == "100")
                                {
                                    if (btnArrayGlobal[actorBlockX + 1, actorBlockY].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX + 1, actorBlockY].PerformClick();
                                        moved = true;
                                    }
                                }
                                else if (blankSpaceX <= (actorBlockX) && blankSpaceY == (actorBlockY - 1) && !moved)
                                {
                                    if (btnArrayGlobal[actorBlockX + 1, actorBlockY].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].PerformClick();
                                        moved = true;
                                    }
                                }
                            }
                            if ((validMoves[1, 1] == true) && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX - 1, actorBlockY].Text == "100")
                                {
                                    if (btnArrayGlobal[actorBlockX - 1, actorBlockY - 1].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX - 1, actorBlockY - 1].PerformClick();
                                        moved = true;
                                    }
                                    else if (validMoves[1, 3] == true)
                                    {
                                        btnArrayGlobal[actorBlockX - 1, actorBlockY + 1].PerformClick();
                                        moved = true;
                                    }
                                }
                            }

                        }
                        if (movingUp && !moved)
                        {
                            if (validMoves[2, 1] == true)
                            {
                                if (btnArrayGlobal[actorBlockX, actorBlockY - 1].Text == "100")
                                {
                                    btnArrayGlobal[actorBlockX, actorBlockY].PerformClick();
                                    moved = true;
                                }
                            }
                            if ((validMoves[3, 1] == true) && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].Text == "100" && !moved)
                                {
                                    if (btnArrayGlobal[actorBlockX, actorBlockY - 1].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX, actorBlockY - 1].PerformClick();
                                        moved = true;
                                    }
                                }
                                else if (blankSpaceX == (actorBlockX + 1) && blankSpaceY >= (actorBlockY) && !moved)
                                {
                                    if (btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].PerformClick();
                                        moved = true;
                                    }

                                }
                            }
                            if ((validMoves[1, 1] == true) && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX - 1, actorBlockY - 1].Text == "100" && !moved)
                                {
                                    if (btnArrayGlobal[actorBlockX, actorBlockY - 1].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX, actorBlockY - 1].PerformClick();
                                        moved = true;
                                    }
                                }
                                else if (blankSpaceX == (actorBlockX - 1) && blankSpaceY >= (actorBlockY) && !moved)
                                {
                                    if (btnArrayGlobal[actorBlockX - 1, actorBlockY - 1].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX - 1, actorBlockY - 1].PerformClick();
                                        moved = true;
                                    }

                                }
                            }
                            if (validMoves[2, 3] == true && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX, actorBlockY + 1].Text == "100")
                                {
                                    if (validMoves[3, 3] == true && !moved)
                                    {
                                        btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].PerformClick();
                                        moved = true;
                                    }
                                    else if (validMoves[1, 3] == true && !moved)
                                    {
                                        btnArrayGlobal[actorBlockX - 1, actorBlockY + 1].PerformClick();
                                        moved = true;
                                    }
                                }
                            }
                            if (validMoves[3, 3] == true && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].Text == "100")
                                {
                                    if (validMoves[3, 1] == true && !moved)
                                    {
                                        btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].PerformClick();
                                        moved = true;
                                    }
                                    else if (validMoves[3, 3] == true && !moved)
                                    {
                                        btnArrayGlobal[actorBlockX - 1, actorBlockY + 1].PerformClick();
                                        moved = true;
                                    }
                                }
                            }
                        }
                        if (movingDown && !moved)
                        {
                            if (validMoves[2, 3] == true && !moved)
                            {

                                if (btnArrayGlobal[actorBlockX, actorBlockY + 1].Text == "100")
                                {
                                    btnArrayGlobal[actorBlockX, actorBlockY].PerformClick();
                                    moved = true;
                                }
                            }
                            if ((validMoves[3, 3] == true) && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].Text == "100")
                                {
                                    if (btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX, actorBlockY - 1].PerformClick();
                                        moved = true;
                                    }
                                }
                                else if (blankSpaceX == (actorBlockX + 1) && blankSpaceY <= (actorBlockY))
                                {
                                    btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].PerformClick();
                                    moved = true;
                                }
                            }
                            if ((validMoves[1, 3] == true) && !moved)
                            {
                                if (btnArrayGlobal[actorBlockX - 1, actorBlockY + 1].Text == "100")
                                {
                                    if (btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].BackColor != Color.Crimson)
                                    {
                                        btnArrayGlobal[actorBlockX, actorBlockY + 1].PerformClick();
                                        moved = true;
                                    }
                                }
                                else if (blankSpaceX == (actorBlockX - 1) && blankSpaceY <= (actorBlockY) && !moved)
                                {
                                    btnArrayGlobal[actorBlockX - 1, actorBlockY + 1].PerformClick();
                                    moved = true;
                                }
                            }
                        }

                        if (actorBlockX == targetX && actorBlockY == targetY + 1 && btnArrayGlobal[actorBlockX, actorBlockY - 1].Text == "100")
                        {
                            btnArrayGlobal[actorBlockX, actorBlockY - 1].PerformClick();
                            moved = true;
                        }
                        if (!moved)
                        {
                            doAvailableMoves(validMoves, actorBlockX, actorBlockY, blankSpaceX, blankSpaceY, targetX, targetY);
                        }

                    }
                    if (moveCounter == 400)
                    {
                        simulation = false;
                        aiMoveCounter = 0;
                        lblAIState.Text = "A.I.:          OFF";
                        reloadButtonEvents();
                        return;
                    }
                    if (aiMoveCounter >= 100)
                    {
                        reloadButtonEvents();
                    }
                    if (simulation && moveCompleted)
                    {
                        Application.DoEvents();
                        System.Threading.Thread.Sleep(simulationSpeed);
                        aiMoveCounter++;
                        AISolver();
                    }
                    else
                    {
                        simulation = false;                       
                        aiMoveCounter = 0;
                        lblAIState.Text = "A.I.:          OFF";
                        reloadButtonEvents();
                        return;
                    }
                }
                else
                {
                    lblAIState.Text = "A.I.:          OFF";
                    return;
                }
                return;
            }
            return;
        }

        private void putActorOnTarget2(bool[,] validMoves, bool[,] validMoves2, int blankSpaceX, int blankSpaceY, bool orientation, bool blankBeside, bool blankBeside2)
        {
            if (!blankBeside && actorHolderX > targetHolderX)
            {
                if (blankSpaceY == actorHolderY)
                {
                    btnArrayGlobal[actorHolderX - 1, actorHolderY].PerformClick();
                }
                else if (blankSpaceY < actorHolderY)
                {
                    btnArrayGlobal[actorHolderX - 1, actorHolderY - 1].PerformClick();
                }
                else if (blankSpaceY > actorHolderY)
                {
                    btnArrayGlobal[actorHolderX - 1, actorHolderY + 1].PerformClick();
                }
            }
            else if (!blankBeside && actorHolderX < targetHolderY)
            {
                if (blankSpaceY == actorHolderY)
                {
                    btnArrayGlobal[actorHolderX + 1, actorHolderY].PerformClick();
                }
                else if (blankSpaceY < actorHolderY)
                {
                    btnArrayGlobal[actorHolderX + 1, actorHolderY - 1].PerformClick();
                }
                else if (blankSpaceY > actorHolderY)
                {
                    btnArrayGlobal[actorHolderX + 1, actorHolderY + 1].PerformClick();
                }
            }
            else if (blankBeside && actorHolderX > targetHolderX)
            {

                if (actorHolderY == rows)
                {
                    if (blankSpaceX > actorHolderX && blankSpaceY == actorHolderY)
                    {
                        btnArrayGlobal[actorHolderX + 1, actorHolderY - 1].PerformClick();
                    }
                    else if (blankSpaceX > actorHolderX && blankSpaceY < actorHolderY)
                    {
                        btnArrayGlobal[actorHolderX, actorHolderY - 1].PerformClick();
                    }
                    else if (blankSpaceX == actorHolderX && blankSpaceY < actorHolderY)
                    {
                        btnArrayGlobal[actorHolderX, actorHolderY].PerformClick();
                    }
                    else if (blankSpaceX < actorHolderX && blankSpaceY < actorHolderY)
                    {
                        btnArrayGlobal[actorHolderX - 1, actorHolderY].PerformClick();
                    }
                    else if (blankSpaceX < actorHolderX && blankSpaceY == actorHolderY)
                    {
                        btnArrayGlobal[actorHolderX, actorHolderY].PerformClick();
                    }
                }
                else if (actorHolderY != rows)
                {
                    if (blankSpaceX > actorHolderX && blankSpaceY == actorHolderY)
                    {
                        btnArrayGlobal[actorHolderX + 1, actorHolderY + 1].PerformClick();
                    }
                    else if (blankSpaceX > actorHolderX && blankSpaceY > actorHolderY)
                    {
                        btnArrayGlobal[actorHolderX, actorHolderY + 1].PerformClick();
                    }
                    else if (blankSpaceX == actorHolderX && blankSpaceY > actorHolderY)
                    {
                        btnArrayGlobal[actorHolderX - 1, actorHolderY + 1].PerformClick();
                    }
                    else if (blankSpaceX < actorHolderX && blankSpaceY > actorHolderY)
                    {
                        btnArrayGlobal[actorHolderX - 1, actorHolderY].PerformClick();
                    }
                    else if (blankSpaceX < actorHolderX && blankSpaceY == actorHolderY)
                    {
                        btnArrayGlobal[actorHolderX, actorHolderY].PerformClick();
                    }
                }
            }
            else if ((blankBeside && actorHolderX < targetHolderX))
            {

            }
        }

        private bool checkForBlankSpace(int actorBlockX, int actorBlockY, bool[,] validMoves)
        {


            if (validMoves[1, 1] == true)
            {
                if (btnArrayGlobal[actorBlockX - 1, actorBlockY - 1].Text == "100")
                {
                    return true;
                }
            }
            if (validMoves[1, 2] == true)
            {
                if (btnArrayGlobal[actorBlockX - 1, actorBlockY].Text == "100")
                {
                    return true;
                }
            }
            if (validMoves[1, 3] == true)
            {
                if (btnArrayGlobal[actorBlockX - 1, actorBlockY + 1].Text == "100")
                {
                    return true;
                }
            }
            if (validMoves[2, 1] == true)
            {
                if (btnArrayGlobal[actorBlockX, actorBlockY - 1].Text == "100")
                {
                    return true;
                }
            }
            if (validMoves[2, 3] == true)
            {
                if (btnArrayGlobal[actorBlockX, actorBlockY + 1].Text == "100")
                {
                    return true;
                }
            }
            if (validMoves[3, 1] == true)
            {
                if (btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].Text == "100")
                {
                    return true;
                }
            }
            if (validMoves[3, 2] == true)
            {
                if (btnArrayGlobal[actorBlockX + 1, actorBlockY].Text == "100")
                {
                    return true;
                }
            }
            if (validMoves[3, 3] == true)
            {
                if (btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].Text == "100")
                {
                    return true;
                }
            }
            return false;
        }

        private bool[,] checkValidSquares(bool[,] validMoves, int actorBlockX, int actorBlockY)
        {
            for (int i = 1; i <= 3; i++)
            {
                validMoves[1, i] = true;
                validMoves[2, i] = true;
                validMoves[3, i] = true;
            }

            //Actor checks valid moves.
            if (actorBlockX == 1)
            {
                validMoves[1, 1] = false;
                validMoves[1, 2] = false;
                validMoves[1, 3] = false;
            }
            if (actorBlockX == columns)
            {
                validMoves[3, 1] = false;
                validMoves[3, 2] = false;
                validMoves[3, 3] = false;
            }
            if (actorBlockY == 1)
            {
                validMoves[1, 1] = false;
                validMoves[2, 1] = false;
                validMoves[3, 1] = false;
            }
            if (actorBlockY == rows)
            {
                validMoves[1, 3] = false;
                validMoves[2, 3] = false;
                validMoves[3, 3] = false;
            }

            return validMoves;
        }

        //private void fillTextBoxDebug(int actorBlockX, int actorBlockY, int targetX, int targetY, int blankSpaceX, int blankSpaceY, int targetNumber, bool blankBeside, int solvingStage, int targetNumber2)
        //{
        //    rchTxtDebug.Text = (" actorX = " + actorBlockX + "\n actorY = " + actorBlockY + "\n targetX = " + targetX + "\n targetY = " + targetY + "\n targetNumber = " +
        //        targetNumber + "\n solvingStage = " + solvingStage + "\n targetNumber2 = " + targetNumber2 + "\n actor holder:  = " + actorHolderX) + "\n actorHolerY = " + actorHolderY;
        //}

        private string adjustStrategy(int targetX, int targetY, int actorBlockX, int actorBlockY, int targetNumber, int targetNumber2, int actorBlockX2, int actorBlockY2)
        {
            if (solvingStage == 0)
            {
                return null;
            }
            if (solvingStage == 1)
            {
                targetNumber = (columns * (rows - 1) + 1);
                targetNumber2 = (columns * (rows - 2) + 1);
                string actorBlockLeft = findActorBlock(targetNumber2);
                string actorBlockRight = findActorBlock(targetNumber);
                string condensedData = actorBlockLeft + "," + actorBlockRight + "," + targetNumber2;
                return condensedData;
            }
            return null;
        }

        private int determineSolvingLogic(int actorBlockX, int actorBlockY, int targetX, int targetY)
        {
            if (btnArrayGlobal[columns, (rows - 2)].BackColor == Color.Crimson && (Convert.ToInt32(btnArrayGlobal[1, (rows - 1)].Text) != (columns * (rows - 2)) + 1 && Convert.ToInt32(btnArrayGlobal[1, rows].Text) != (columns * (rows - 1) + 1)))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        private string findBlankSpace()
        {
            int counterX = 1;
            int counterY = 1;

            string condensedData;

            for (int i = 0; i < (columns * rows); i++)
            {
                if (Convert.ToInt32(btnArrayGlobal[counterX, counterY].Text) == 100)
                {
                    condensedData = counterX + "," + counterY;
                    return condensedData;
                }

                if (counterX != columns)
                {
                    counterX++;
                }
                else
                {
                    counterX = 1;
                    counterY++;
                }
            }
            return null;
        }

        private string findActorBlock(int targetNumber)
        {
            int counterX = 1;
            int counterY = 1;

            string condensedData = null;

            for (int i = 0; i < (columns * rows); i++)
            {
                if (Convert.ToInt32(btnArrayGlobal[counterX, counterY].Text) == targetNumber)
                {
                    condensedData = counterX + "," + counterY;
                    return condensedData;
                }

                if (counterX != columns)
                {
                    counterX++;
                }
                else
                {
                    counterX = 1;
                    counterY++;
                }
            }
            return null;
        }


        private int extractCondensedVariables(string condensedData, int requiredValue)
        {
            string[] dataExtraction = condensedData.Split(',');
            return Convert.ToInt32(dataExtraction[requiredValue]);
        }

        private string findTargetToMoveTo()
        {
            int targetX;
            int targetY;

            int counterX = 1;
            int counterY = 1;

            int targetNumber = 0;

            string condensedData = null;
            string[] inputFields;

            for (int i = 0; i < (columns * rows); i++)
            {
                if (Convert.ToInt32(btnArrayGlobal[counterX, counterY].Text) == i)
                {
                    btnArrayGlobal[counterX, counterY].BackColor = Color.Crimson;
                }

                else
                {
                    targetX = counterX;
                    targetY = counterY;
                    targetNumber = i;

                    if (solvingStage == 0)
                    {
                        if (targetX == columns - 1 && Convert.ToInt32(btnArrayGlobal[targetX, targetY].Text) != (i + 1))
                        {
                            targetNumber = i + 1;
                        }
                        else
                        {
                            targetNumber = i;
                        }
                    }
                    condensedData = targetX + "," + targetY + "," + targetNumber;
                    return condensedData;
                }

                if (counterX != columns)
                {
                    counterX++;
                }
                else
                {
                    counterX = 1;
                    counterY++;
                }
            }
            return condensedData;
        }

        private void putActorOnTarget(bool[,] validMoves, int targetX, int targetY, int actorBlockX, int actorBlockY, int blankSpaceX, int blankSpaceY)
        {
            if (AICounter2 == 1)
            {
                targetHolderX = targetX;
                targetHolderY = targetY;
                actorHolderX = actorBlockX;
                actorHolderY = actorBlockY;
                AICounter2 = 2;
            }
            if (AICounter2 == 2)
            {
                if (blankSpaceX == (actorHolderX - 1) && blankSpaceY == actorHolderY && actorHolderY != rows)
                {
                    btnArrayGlobal[actorHolderX - 1, actorHolderY + 1].PerformClick();
                }
                else if (blankSpaceX == (actorHolderX - 1) && blankSpaceY == actorHolderY + 1 && actorHolderX != columns && actorHolderY != rows)
                {
                    btnArrayGlobal[actorHolderX + 1, actorHolderY + 1].PerformClick();
                }
                else if (blankSpaceX == (actorHolderX) && blankSpaceY == actorHolderY + 1 && actorHolderX != columns && actorHolderY != rows)
                {
                    btnArrayGlobal[actorHolderX + 1, actorHolderY + 1].PerformClick();
                }
                else if (blankSpaceX == (actorHolderX + 1) && blankSpaceY == actorHolderY + 1 && actorHolderX != columns && actorHolderY != rows)
                {
                    btnArrayGlobal[actorHolderX + 1, actorHolderY].PerformClick();
                }
                else if (blankSpaceX == (actorHolderX + 1) && blankSpaceY == actorHolderY)
                {
                    AICounter2 = 3;
                }
                else if (blankSpaceX == actorHolderX + 1 && blankSpaceY == actorHolderY - 1)
                {
                    btnArrayGlobal[actorHolderX + 1, actorHolderY].PerformClick();
                }
                else if (blankSpaceX == (actorHolderX) && blankSpaceY == actorHolderY - 1)
                {
                    btnArrayGlobal[actorHolderX, actorHolderY].PerformClick();

                    AICounter2 = 0;
                }
                else if (blankSpaceX == (actorHolderX - 1) && blankSpaceY == actorHolderY - 1)
                {
                    btnArrayGlobal[actorHolderX - 1, actorHolderY].PerformClick();

                    AICounter2 = 0;
                }
            }
            if (AICounter2 >= 3)
            {
                switch (AICounter2)
                {
                    case 3:
                        {
                            btnArrayGlobal[actorHolderX, actorHolderY].PerformClick();
                            actorHolderX = actorHolderX + 1;
                            AICounter2++;
                            break;
                        }
                    case 4:
                        {
                            btnArrayGlobal[actorHolderX - 1, actorHolderY - 1].PerformClick();
                            AICounter2++;
                            break;
                        }
                    case 5:
                        {
                            btnArrayGlobal[actorHolderX, actorHolderY - 1].PerformClick();
                            AICounter2++;
                            break;
                        }
                    case 6:
                        {
                            btnArrayGlobal[actorHolderX, actorHolderY].PerformClick();
                            actorHolderY = actorHolderY - 1;
                            AICounter2++;
                            break;
                        }
                    case 7:
                        {
                            btnArrayGlobal[actorHolderX - 1, actorHolderY + 1].PerformClick();
                            AICounter2++;
                            break;
                        }
                    case 8:
                        {
                            btnArrayGlobal[actorHolderX - 1, actorHolderY].PerformClick();
                            AICounter2++;
                            break;
                        }
                    case 9:
                        {
                            btnArrayGlobal[actorHolderX, actorHolderY].PerformClick();
                            AICounter2 = 0;
                            break;
                        }

                }
            }
        }



        private void doAvailableMoves(bool[,] validMoves, int actorBlockX, int actorBlockY, int blankSpaceX, int blankSpaceY, int targetX, int targetY)
        {
            moveCompleted = false;
            if (AICounter == 0 && !moveCompleted)
            {
                AICounter = 1;
                if (validMoves[1, 1] == true)
                {
                    if (btnArrayGlobal[actorBlockX - 1, actorBlockY - 1].BackColor != Color.Crimson)
                    {
                        btnArrayGlobal[actorBlockX - 1, actorBlockY - 1].PerformClick();
                        moveCompleted = true;
                    }
                }
            }
            if (AICounter == 1 && !moveCompleted)
            {
                AICounter = 2;
                if (validMoves[2, 1] == true)
                {
                    if (btnArrayGlobal[actorBlockX, actorBlockY - 1].BackColor != Color.Crimson)
                    {
                        btnArrayGlobal[actorBlockX, actorBlockY - 1].PerformClick();
                        moveCompleted = true;
                    }

                }
            }
            if (AICounter == 2 && !moveCompleted)
            {
                if (validMoves[3, 1] == true)
                {
                    AICounter = 3;
                    if (btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].BackColor != Color.Crimson)
                    {
                        btnArrayGlobal[actorBlockX + 1, actorBlockY - 1].PerformClick();
                        moveCompleted = true;
                    }
                }
            }
            if (AICounter == 3 && !moveCompleted)
            {
                AICounter = 4;
                if (validMoves[3, 2] == true)
                {
                    if (btnArrayGlobal[actorBlockX + 1, actorBlockY].BackColor != Color.Crimson)
                    {
                        btnArrayGlobal[actorBlockX + 1, actorBlockY].PerformClick();
                        moveCompleted = true;
                    }
                }
            }
            if (AICounter == 4 && !moveCompleted)
            {
                AICounter = 5;
                if (validMoves[3, 3] == true)
                {
                    if (btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].BackColor != Color.Crimson)
                    {
                        btnArrayGlobal[actorBlockX + 1, actorBlockY + 1].PerformClick();
                        moveCompleted = true;
                    }
                }
            }
            if (AICounter == 5)
            {
                AICounter = 6;
                if (validMoves[2, 3] == true && !moveCompleted)
                {
                    if (btnArrayGlobal[actorBlockX, actorBlockY + 1].BackColor != Color.Crimson)
                    {
                        btnArrayGlobal[actorBlockX, actorBlockY + 1].PerformClick();
                        moveCompleted = true;
                    }
                }
            }
            if (AICounter == 6 && !moveCompleted)
            {
                if (validMoves[1, 3] == true)
                {
                    AICounter = 7;
                    if (btnArrayGlobal[actorBlockX - 1, actorBlockY + 1].BackColor != Color.Crimson)
                    {
                        btnArrayGlobal[actorBlockX - 1, actorBlockY + 1].PerformClick();
                        moveCompleted = true;
                    }
                }
            }
            if (AICounter == 7 && !moveCompleted)
            {
                AICounter = 0;
                if (validMoves[1, 2] == true)
                {
                    if (btnArrayGlobal[actorBlockX - 1, actorBlockY].BackColor != Color.Crimson)
                    {
                        btnArrayGlobal[actorBlockX - 1, actorBlockY].PerformClick();
                        moveCompleted = true;
                    }
                }
            }
        }

        private void btnCheatToggle_Click(object sender, EventArgs e)
        {
            if (!cheatingAllowed)
            {
                cheatingAllowed = true;
                btnCheatToggle.Text = "Cheats: On";
                lblCheats.Text = "Cheats: On";
            }
            else
            {
                cheatingAllowed = false;
                btnCheatToggle.Text = "Cheats: Off";
                lblCheats.Text = "Cheats: Off";
            }
        }

        private void btnRandom_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            columns = rnd.Next(3, 9);
            System.Threading.Thread.Sleep(20);
            rows = rnd.Next(3, 9);
            txtBoxColumns.Text = columns.ToString();
            txtBoxRows.Text = rows.ToString();
            btnAddButton.PerformClick();
        }

        private void btnHighScores_Click(object sender, EventArgs e)
        {
            pnlMainScreen.BackgroundImage = Image.FromFile("../Resources/highScore.jpg");     
            string scores = "";

            for (int i = 3; i < 10; i++)
            {
                for (int x = 3; x < 10; x++)
                {
                    scores += "Stage [" + i + "," + x + "] :    " + highScores[i, x].ToString() + "   " + strHighscores[i,x] +  "\n";
                }
            }
            lblHighScores.Visible = true;
            lblHighScores.Enabled = true;
            lblHighScores.Text = scores;
            pnlMenuWindow.Visible = false;
            pnlMenuWindow.Enabled = false;
            
        }

        private void btnName_Click(object sender, EventArgs e)
        {
            btnName.Visible = false;
            btnName.Enabled = false;
            btnHighScores.Visible = false;
            btnHighScores.Enabled = false;
            btnCheatToggle.Visible = false;
            btnCheatToggle.Enabled = false;
            btnRandom.Enabled = false;
            btnRandom.Visible = false;
            txtBoxName.Enabled = true;
            txtBoxName.Visible = true;
            btnNameGood.Visible = true;
            btnNameGood.Enabled = true;
            lblEnterName.Visible = true;
            lblEnterName.Enabled = true;
            pnlMenuWindow.BackgroundImage = Image.FromFile("../Resources/menuWindowName.jpg");          
        }

        private void btnNameGood_Click(object sender, EventArgs e)
        {
            if (txtBoxName.Text.Length < 9)
            {
                lblNamePlate.Text = txtBoxName.Text;
                lblNameSmall.Text = txtBoxName.Text;
                txtBoxName.Text = "";
                idleState();
            }
            else
            {
                lblEnterName.Text = "Maximum 8 Characters";
            }
        }


        private void txtBoxName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnNameGood.PerformClick();
            }
            else return;
        }

        private void lblNamePlate_Click(object sender, EventArgs e)
        {

        }


    }
}
