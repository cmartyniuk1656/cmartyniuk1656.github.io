﻿namespace CMAssignment3Rebuild
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlMainScreen = new System.Windows.Forms.Panel();
            this.lblHighScores = new System.Windows.Forms.Label();
            this.pnlMenuWindow = new System.Windows.Forms.Panel();
            this.lblEnterName = new System.Windows.Forms.Label();
            this.btnNameGood = new System.Windows.Forms.Button();
            this.txtBoxName = new System.Windows.Forms.TextBox();
            this.btnName = new System.Windows.Forms.Button();
            this.btnCheatToggle = new System.Windows.Forms.Button();
            this.btnHighScores = new System.Windows.Forms.Button();
            this.btnRandom = new System.Windows.Forms.Button();
            this.pnlButtonsMain = new System.Windows.Forms.Panel();
            this.rchTxtDebug = new System.Windows.Forms.RichTextBox();
            this.lblCheats = new System.Windows.Forms.Label();
            this.lblAIState = new System.Windows.Forms.Label();
            this.pnlBottomInterface = new System.Windows.Forms.Panel();
            this.pnlNamePlate = new System.Windows.Forms.Panel();
            this.lblNamePlate = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtBoxRows = new System.Windows.Forms.TextBox();
            this.btnAddButton = new System.Windows.Forms.Button();
            this.txtBoxColumns = new System.Windows.Forms.TextBox();
            this.lblRows = new System.Windows.Forms.Label();
            this.lblColumns = new System.Windows.Forms.Label();
            this.btnLoad = new System.Windows.Forms.Button();
            this.pnlLeftInterface = new System.Windows.Forms.Panel();
            this.pnlStats = new System.Windows.Forms.Panel();
            this.lblLevelTitle = new System.Windows.Forms.Label();
            this.lblLevel = new System.Windows.Forms.Label();
            this.lblCheatsUsed = new System.Windows.Forms.Label();
            this.lblMoves = new System.Windows.Forms.Label();
            this.lblWins = new System.Windows.Forms.Label();
            this.lblNameSmall = new System.Windows.Forms.Label();
            this.btnCheat = new System.Windows.Forms.Button();
            this.lblMenu = new System.Windows.Forms.Label();
            this.btnSimulate = new System.Windows.Forms.Button();
            this.pnlMainScreen.SuspendLayout();
            this.pnlMenuWindow.SuspendLayout();
            this.pnlBottomInterface.SuspendLayout();
            this.pnlNamePlate.SuspendLayout();
            this.pnlLeftInterface.SuspendLayout();
            this.pnlStats.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlButtons
            // 
            this.pnlButtons.Location = new System.Drawing.Point(0, 0);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(200, 100);
            this.pnlButtons.TabIndex = 0;
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Capture it", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.Turquoise;
            this.lblTitle.Location = new System.Drawing.Point(106, 68);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(456, 100);
            this.lblTitle.TabIndex = 14;
            this.lblTitle.Text = "N-Puzzle";
            // 
            // pnlMainScreen
            // 
            this.pnlMainScreen.BackColor = System.Drawing.Color.Transparent;
            this.pnlMainScreen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlMainScreen.Controls.Add(this.lblHighScores);
            this.pnlMainScreen.Controls.Add(this.pnlMenuWindow);
            this.pnlMainScreen.Controls.Add(this.pnlButtonsMain);
            this.pnlMainScreen.Controls.Add(this.rchTxtDebug);
            this.pnlMainScreen.Location = new System.Drawing.Point(142, 1);
            this.pnlMainScreen.Name = "pnlMainScreen";
            this.pnlMainScreen.Size = new System.Drawing.Size(641, 553);
            this.pnlMainScreen.TabIndex = 14;
            // 
            // lblHighScores
            // 
            this.lblHighScores.AutoSize = true;
            this.lblHighScores.BackColor = System.Drawing.Color.Transparent;
            this.lblHighScores.ForeColor = System.Drawing.Color.Gold;
            this.lblHighScores.Location = new System.Drawing.Point(49, 27);
            this.lblHighScores.Name = "lblHighScores";
            this.lblHighScores.Size = new System.Drawing.Size(0, 13);
            this.lblHighScores.TabIndex = 15;
            // 
            // pnlMenuWindow
            // 
            this.pnlMenuWindow.BackColor = System.Drawing.Color.DimGray;
            this.pnlMenuWindow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlMenuWindow.Controls.Add(this.lblEnterName);
            this.pnlMenuWindow.Controls.Add(this.btnNameGood);
            this.pnlMenuWindow.Controls.Add(this.txtBoxName);
            this.pnlMenuWindow.Controls.Add(this.btnName);
            this.pnlMenuWindow.Controls.Add(this.btnCheatToggle);
            this.pnlMenuWindow.Controls.Add(this.btnHighScores);
            this.pnlMenuWindow.Controls.Add(this.btnRandom);
            this.pnlMenuWindow.Location = new System.Drawing.Point(138, 179);
            this.pnlMenuWindow.Name = "pnlMenuWindow";
            this.pnlMenuWindow.Size = new System.Drawing.Size(364, 220);
            this.pnlMenuWindow.TabIndex = 1;
            // 
            // lblEnterName
            // 
            this.lblEnterName.BackColor = System.Drawing.Color.Transparent;
            this.lblEnterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.lblEnterName.Location = new System.Drawing.Point(27, 85);
            this.lblEnterName.Name = "lblEnterName";
            this.lblEnterName.Size = new System.Drawing.Size(306, 24);
            this.lblEnterName.TabIndex = 15;
            this.lblEnterName.Text = "Enter Your Name";
            this.lblEnterName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnNameGood
            // 
            this.btnNameGood.BackColor = System.Drawing.Color.White;
            this.btnNameGood.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNameGood.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNameGood.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnNameGood.Location = new System.Drawing.Point(134, 31);
            this.btnNameGood.Name = "btnNameGood";
            this.btnNameGood.Size = new System.Drawing.Size(93, 50);
            this.btnNameGood.TabIndex = 20;
            this.btnNameGood.Text = "OK";
            this.btnNameGood.UseVisualStyleBackColor = false;
            this.btnNameGood.Click += new System.EventHandler(this.btnNameGood_Click);
            // 
            // txtBoxName
            // 
            this.txtBoxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxName.ForeColor = System.Drawing.SystemColors.MenuText;
            this.txtBoxName.Location = new System.Drawing.Point(53, 130);
            this.txtBoxName.Name = "txtBoxName";
            this.txtBoxName.Size = new System.Drawing.Size(262, 47);
            this.txtBoxName.TabIndex = 19;
            this.txtBoxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBoxName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBoxName_KeyDown);
            // 
            // btnName
            // 
            this.btnName.BackColor = System.Drawing.Color.White;
            this.btnName.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnName.Location = new System.Drawing.Point(197, 33);
            this.btnName.Name = "btnName";
            this.btnName.Size = new System.Drawing.Size(104, 66);
            this.btnName.TabIndex = 18;
            this.btnName.Text = "Change Name";
            this.btnName.UseVisualStyleBackColor = false;
            this.btnName.Click += new System.EventHandler(this.btnName_Click);
            // 
            // btnCheatToggle
            // 
            this.btnCheatToggle.BackColor = System.Drawing.Color.White;
            this.btnCheatToggle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCheatToggle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCheatToggle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnCheatToggle.Location = new System.Drawing.Point(63, 125);
            this.btnCheatToggle.Name = "btnCheatToggle";
            this.btnCheatToggle.Size = new System.Drawing.Size(104, 66);
            this.btnCheatToggle.TabIndex = 17;
            this.btnCheatToggle.Text = "Cheats: ON";
            this.btnCheatToggle.UseVisualStyleBackColor = false;
            this.btnCheatToggle.Click += new System.EventHandler(this.btnCheatToggle_Click);
            // 
            // btnHighScores
            // 
            this.btnHighScores.BackColor = System.Drawing.Color.White;
            this.btnHighScores.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHighScores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHighScores.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnHighScores.Location = new System.Drawing.Point(197, 125);
            this.btnHighScores.Name = "btnHighScores";
            this.btnHighScores.Size = new System.Drawing.Size(104, 66);
            this.btnHighScores.TabIndex = 16;
            this.btnHighScores.Text = "High Scores";
            this.btnHighScores.UseVisualStyleBackColor = false;
            this.btnHighScores.Click += new System.EventHandler(this.btnHighScores_Click);
            // 
            // btnRandom
            // 
            this.btnRandom.BackColor = System.Drawing.Color.White;
            this.btnRandom.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRandom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRandom.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnRandom.Location = new System.Drawing.Point(63, 33);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(104, 66);
            this.btnRandom.TabIndex = 15;
            this.btnRandom.Text = "Random Puzzle";
            this.btnRandom.UseVisualStyleBackColor = false;
            this.btnRandom.Click += new System.EventHandler(this.btnRandom_Click);
            // 
            // pnlButtonsMain
            // 
            this.pnlButtonsMain.AutoScroll = true;
            this.pnlButtonsMain.BackColor = System.Drawing.Color.Black;
            this.pnlButtonsMain.Font = new System.Drawing.Font("Capture it", 14.25F, System.Drawing.FontStyle.Bold);
            this.pnlButtonsMain.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnlButtonsMain.Location = new System.Drawing.Point(430, 3);
            this.pnlButtonsMain.Name = "pnlButtonsMain";
            this.pnlButtonsMain.Size = new System.Drawing.Size(211, 144);
            this.pnlButtonsMain.TabIndex = 0;
            // 
            // rchTxtDebug
            // 
            this.rchTxtDebug.Location = new System.Drawing.Point(0, -4);
            this.rchTxtDebug.Name = "rchTxtDebug";
            this.rchTxtDebug.Size = new System.Drawing.Size(103, 226);
            this.rchTxtDebug.TabIndex = 14;
            this.rchTxtDebug.Text = "";
            this.rchTxtDebug.Visible = false;
            // 
            // lblCheats
            // 
            this.lblCheats.AutoSize = true;
            this.lblCheats.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblCheats.Location = new System.Drawing.Point(10, 4);
            this.lblCheats.Name = "lblCheats";
            this.lblCheats.Size = new System.Drawing.Size(99, 20);
            this.lblCheats.TabIndex = 15;
            this.lblCheats.Text = "Cheats: On";
            // 
            // lblAIState
            // 
            this.lblAIState.AutoSize = true;
            this.lblAIState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblAIState.Location = new System.Drawing.Point(10, 26);
            this.lblAIState.Name = "lblAIState";
            this.lblAIState.Size = new System.Drawing.Size(97, 20);
            this.lblAIState.TabIndex = 13;
            this.lblAIState.Text = "A.I.:    OFF";
            // 
            // pnlBottomInterface
            // 
            this.pnlBottomInterface.BackColor = System.Drawing.Color.Transparent;
            this.pnlBottomInterface.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnlBottomInterface.Controls.Add(this.pnlNamePlate);
            this.pnlBottomInterface.Controls.Add(this.btnSave);
            this.pnlBottomInterface.Controls.Add(this.btnClear);
            this.pnlBottomInterface.Controls.Add(this.txtBoxRows);
            this.pnlBottomInterface.Controls.Add(this.btnAddButton);
            this.pnlBottomInterface.Controls.Add(this.txtBoxColumns);
            this.pnlBottomInterface.Controls.Add(this.lblRows);
            this.pnlBottomInterface.Controls.Add(this.lblColumns);
            this.pnlBottomInterface.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnlBottomInterface.Location = new System.Drawing.Point(-1, 553);
            this.pnlBottomInterface.Name = "pnlBottomInterface";
            this.pnlBottomInterface.Size = new System.Drawing.Size(784, 109);
            this.pnlBottomInterface.TabIndex = 12;
            // 
            // pnlNamePlate
            // 
            this.pnlNamePlate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlNamePlate.Controls.Add(this.lblNamePlate);
            this.pnlNamePlate.Location = new System.Drawing.Point(150, 14);
            this.pnlNamePlate.Name = "pnlNamePlate";
            this.pnlNamePlate.Size = new System.Drawing.Size(265, 84);
            this.pnlNamePlate.TabIndex = 10;
            // 
            // lblNamePlate
            // 
            this.lblNamePlate.Location = new System.Drawing.Point(3, 3);
            this.lblNamePlate.Name = "lblNamePlate";
            this.lblNamePlate.Size = new System.Drawing.Size(259, 79);
            this.lblNamePlate.TabIndex = 10;
            this.lblNamePlate.Text = "Player";
            this.lblNamePlate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblNamePlate.Click += new System.EventHandler(this.lblNamePlate_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Black;
            this.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnSave.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSave.Location = new System.Drawing.Point(11, 16);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(112, 83);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save Game";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Black;
            this.btnClear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnClear.Location = new System.Drawing.Point(436, 16);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(112, 83);
            this.btnClear.TabIndex = 4;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtBoxRows
            // 
            this.txtBoxRows.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txtBoxRows.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxRows.Location = new System.Drawing.Point(670, 58);
            this.txtBoxRows.Name = "txtBoxRows";
            this.txtBoxRows.Size = new System.Drawing.Size(99, 20);
            this.txtBoxRows.TabIndex = 2;
            // 
            // btnAddButton
            // 
            this.btnAddButton.BackColor = System.Drawing.Color.Black;
            this.btnAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnAddButton.Location = new System.Drawing.Point(436, 16);
            this.btnAddButton.Name = "btnAddButton";
            this.btnAddButton.Size = new System.Drawing.Size(112, 83);
            this.btnAddButton.TabIndex = 1;
            this.btnAddButton.Text = "Play";
            this.btnAddButton.UseVisualStyleBackColor = false;
            this.btnAddButton.Click += new System.EventHandler(this.btnAddButton_Click);
            // 
            // txtBoxColumns
            // 
            this.txtBoxColumns.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txtBoxColumns.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxColumns.Location = new System.Drawing.Point(670, 27);
            this.txtBoxColumns.Name = "txtBoxColumns";
            this.txtBoxColumns.Size = new System.Drawing.Size(99, 20);
            this.txtBoxColumns.TabIndex = 3;
            // 
            // lblRows
            // 
            this.lblRows.AutoSize = true;
            this.lblRows.BackColor = System.Drawing.Color.Transparent;
            this.lblRows.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.lblRows.Location = new System.Drawing.Point(589, 58);
            this.lblRows.Name = "lblRows";
            this.lblRows.Size = new System.Drawing.Size(67, 24);
            this.lblRows.TabIndex = 9;
            this.lblRows.Text = "Rows:";
            // 
            // lblColumns
            // 
            this.lblColumns.AutoSize = true;
            this.lblColumns.BackColor = System.Drawing.Color.Transparent;
            this.lblColumns.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.lblColumns.Location = new System.Drawing.Point(554, 28);
            this.lblColumns.Name = "lblColumns";
            this.lblColumns.Size = new System.Drawing.Size(98, 24);
            this.lblColumns.TabIndex = 6;
            this.lblColumns.Text = "Columns:";
            // 
            // btnLoad
            // 
            this.btnLoad.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLoad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnLoad.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnLoad.Location = new System.Drawing.Point(11, 467);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLoad.Size = new System.Drawing.Size(112, 83);
            this.btnLoad.TabIndex = 8;
            this.btnLoad.Text = "Load Game";
            this.btnLoad.UseVisualStyleBackColor = false;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // pnlLeftInterface
            // 
            this.pnlLeftInterface.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLeftInterface.BackColor = System.Drawing.Color.Transparent;
            this.pnlLeftInterface.Controls.Add(this.btnLoad);
            this.pnlLeftInterface.Controls.Add(this.pnlStats);
            this.pnlLeftInterface.Controls.Add(this.btnCheat);
            this.pnlLeftInterface.Controls.Add(this.lblMenu);
            this.pnlLeftInterface.Controls.Add(this.btnSimulate);
            this.pnlLeftInterface.Location = new System.Drawing.Point(-1, 1);
            this.pnlLeftInterface.Name = "pnlLeftInterface";
            this.pnlLeftInterface.Size = new System.Drawing.Size(146, 553);
            this.pnlLeftInterface.TabIndex = 13;
            // 
            // pnlStats
            // 
            this.pnlStats.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlStats.Controls.Add(this.lblLevelTitle);
            this.pnlStats.Controls.Add(this.lblLevel);
            this.pnlStats.Controls.Add(this.lblCheatsUsed);
            this.pnlStats.Controls.Add(this.lblMoves);
            this.pnlStats.Controls.Add(this.lblWins);
            this.pnlStats.Controls.Add(this.lblNameSmall);
            this.pnlStats.Controls.Add(this.lblCheats);
            this.pnlStats.Controls.Add(this.lblAIState);
            this.pnlStats.Location = new System.Drawing.Point(5, 232);
            this.pnlStats.Name = "pnlStats";
            this.pnlStats.Size = new System.Drawing.Size(124, 232);
            this.pnlStats.TabIndex = 13;
            // 
            // lblLevelTitle
            // 
            this.lblLevelTitle.AutoSize = true;
            this.lblLevelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblLevelTitle.Location = new System.Drawing.Point(4, 96);
            this.lblLevelTitle.Name = "lblLevelTitle";
            this.lblLevelTitle.Size = new System.Drawing.Size(87, 20);
            this.lblLevelTitle.TabIndex = 19;
            this.lblLevelTitle.Text = "---Level---";
            // 
            // lblLevel
            // 
            this.lblLevel.Location = new System.Drawing.Point(-2, 120);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(132, 65);
            this.lblLevel.TabIndex = 19;
            // 
            // lblCheatsUsed
            // 
            this.lblCheatsUsed.AutoSize = true;
            this.lblCheatsUsed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblCheatsUsed.Location = new System.Drawing.Point(7, 76);
            this.lblCheatsUsed.Name = "lblCheatsUsed";
            this.lblCheatsUsed.Size = new System.Drawing.Size(76, 20);
            this.lblCheatsUsed.TabIndex = 18;
            this.lblCheatsUsed.Text = "Cheats: ";
            // 
            // lblMoves
            // 
            this.lblMoves.AutoSize = true;
            this.lblMoves.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblMoves.Location = new System.Drawing.Point(8, 53);
            this.lblMoves.Name = "lblMoves";
            this.lblMoves.Size = new System.Drawing.Size(70, 20);
            this.lblMoves.TabIndex = 17;
            this.lblMoves.Text = "Moves: ";
            // 
            // lblWins
            // 
            this.lblWins.AutoSize = true;
            this.lblWins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblWins.Location = new System.Drawing.Point(10, 205);
            this.lblWins.Name = "lblWins";
            this.lblWins.Size = new System.Drawing.Size(68, 20);
            this.lblWins.TabIndex = 17;
            this.lblWins.Text = "Wins: 0";
            // 
            // lblNameSmall
            // 
            this.lblNameSmall.AutoSize = true;
            this.lblNameSmall.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblNameSmall.Location = new System.Drawing.Point(10, 185);
            this.lblNameSmall.Name = "lblNameSmall";
            this.lblNameSmall.Size = new System.Drawing.Size(55, 20);
            this.lblNameSmall.TabIndex = 16;
            this.lblNameSmall.Text = "Name";
            // 
            // btnCheat
            // 
            this.btnCheat.BackColor = System.Drawing.Color.Black;
            this.btnCheat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCheat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCheat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnCheat.Location = new System.Drawing.Point(13, 78);
            this.btnCheat.Name = "btnCheat";
            this.btnCheat.Size = new System.Drawing.Size(109, 69);
            this.btnCheat.TabIndex = 10;
            this.btnCheat.Text = "Cheat";
            this.btnCheat.UseVisualStyleBackColor = false;
            this.btnCheat.Click += new System.EventHandler(this.btnCheat_Click);
            // 
            // lblMenu
            // 
            this.lblMenu.AutoSize = true;
            this.lblMenu.BackColor = System.Drawing.Color.Transparent;
            this.lblMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMenu.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblMenu.Location = new System.Drawing.Point(-2, 8);
            this.lblMenu.Name = "lblMenu";
            this.lblMenu.Size = new System.Drawing.Size(149, 55);
            this.lblMenu.TabIndex = 0;
            this.lblMenu.Text = "Menu";
            // 
            // btnSimulate
            // 
            this.btnSimulate.BackColor = System.Drawing.Color.Black;
            this.btnSimulate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSimulate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSimulate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnSimulate.Location = new System.Drawing.Point(13, 153);
            this.btnSimulate.Name = "btnSimulate";
            this.btnSimulate.Size = new System.Drawing.Size(109, 69);
            this.btnSimulate.TabIndex = 12;
            this.btnSimulate.Text = "A.I.";
            this.btnSimulate.UseVisualStyleBackColor = false;
            this.btnSimulate.Click += new System.EventHandler(this.btnSimulate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(784, 662);
            this.Controls.Add(this.pnlMainScreen);
            this.Controls.Add(this.pnlLeftInterface);
            this.Controls.Add(this.pnlBottomInterface);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "vz";
            this.TransparencyKey = System.Drawing.Color.Aqua;
            this.pnlMainScreen.ResumeLayout(false);
            this.pnlMainScreen.PerformLayout();
            this.pnlMenuWindow.ResumeLayout(false);
            this.pnlMenuWindow.PerformLayout();
            this.pnlBottomInterface.ResumeLayout(false);
            this.pnlBottomInterface.PerformLayout();
            this.pnlNamePlate.ResumeLayout(false);
            this.pnlLeftInterface.ResumeLayout(false);
            this.pnlLeftInterface.PerformLayout();
            this.pnlStats.ResumeLayout(false);
            this.pnlStats.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAddButton;
        private System.Windows.Forms.TextBox txtBoxRows;
        private System.Windows.Forms.TextBox txtBoxColumns;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblColumns;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Label lblRows;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lblMenu;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCheat;
        private System.Windows.Forms.Button btnSimulate;
        private System.Windows.Forms.Label lblAIState;
        private System.Windows.Forms.RichTextBox rchTxtDebug;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlBottomInterface;
        private System.Windows.Forms.Panel pnlLeftInterface;
        private System.Windows.Forms.Panel pnlMainScreen;
        private System.Windows.Forms.Panel pnlButtonsMain;
        private System.Windows.Forms.Panel pnlMenuWindow;
        private System.Windows.Forms.Button btnName;
        private System.Windows.Forms.Button btnCheatToggle;
        private System.Windows.Forms.Button btnHighScores;
        private System.Windows.Forms.Button btnRandom;
        private System.Windows.Forms.Label lblCheats;
        private System.Windows.Forms.Panel pnlStats;
        private System.Windows.Forms.Label lblMoves;
        private System.Windows.Forms.Label lblWins;
        private System.Windows.Forms.Label lblNameSmall;
        private System.Windows.Forms.Label lblCheatsUsed;
        private System.Windows.Forms.TextBox txtBoxName;
        private System.Windows.Forms.Label lblEnterName;
        private System.Windows.Forms.Button btnNameGood;
        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.Label lblLevelTitle;
        private System.Windows.Forms.Label lblNamePlate;
        private System.Windows.Forms.Panel pnlNamePlate;
        private System.Windows.Forms.Label lblHighScores;
    }
}

